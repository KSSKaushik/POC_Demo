"""
CCDA Analyzer — Databricks Deployment Entry Point
Only registers the CCDA router. No SQL Server, no Flask, no other features.
Run with: uvicorn main_databricks:app --host 0.0.0.0 --port 8000
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import ccda_router

app = FastAPI(title="CCDA Analyzer", version="15.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(ccda_router.router)

# Serve the built React frontend from frontend/dist
app.mount("/", StaticFiles(directory="frontend/dist_ccda", html=True), name="static")
