"""
CCDA Analyzer — Databricks Deployment Entry Point
Only registers the CCDA router. No SQL Server, no Flask, no other features.
Run with: uvicorn main_databricks:app --host 0.0.0.0 --port 8000
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from routers import ccda

app = FastAPI(title="CCDA Analyzer", version="15.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(ccda.router)

# Serve the built React frontend from frontend/dist
app.mount("/", StaticFiles(directory="frontend/dist_ccda", html=True), name="static")
