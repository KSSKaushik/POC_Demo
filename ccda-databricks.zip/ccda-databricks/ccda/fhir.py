import uuid
from datetime import datetime
from lxml import etree
from .constants import OID, OID2SYS
from .parser import find_section, find_all, find_child, get_attr, get_text, child_text, pat_info


def _uuid() -> str:
    return str(uuid.uuid4())


def _clean(obj):
    if isinstance(obj, dict):
        return {k: _clean(v) for k, v in obj.items() if v is not None}
    if isinstance(obj, list):
        return [_clean(v) for v in obj]
    return obj


def _fhir_date(s: str | None) -> str | None:
    if not s or len(s) < 8:
        return None
    y, mo, d = s[:4], s[4:6], s[6:8]
    if len(s) >= 14:
        return f"{y}-{mo}-{d}T{s[8:10]}:{s[10:12]}:{s[12:14]}"
    return f"{y}-{mo}-{d}"


def _oid2sys(oid: str) -> str:
    return OID2SYS.get(oid, f"urn:oid:{oid}")


def _fcc(code: str, oid: str, disp: str) -> dict:
    return {
        "coding": [{"system": _oid2sys(oid), "code": code or "", "display": disp or ""}],
        "text": disp or code or "",
    }


def _get_el_attr(el, attr: str, default=None):
    if el is None:
        return default
    return el.get(attr, default)


def _local(el) -> str:
    if el is None:
        return ""
    return etree.QName(el.tag).localname


def _find_by_local(parent, *local_tags):
    if parent is None:
        return None
    for el in parent.iter():
        if _local(el) in local_tags:
            return el
    return None


def _find_all_by_local(parent, local_tag: str):
    if parent is None:
        return []
    return [el for el in parent.iter() if _local(el) == local_tag]


def _text(el) -> str:
    if el is None:
        return ""
    return (el.text or "").strip()


def fhir_patient(root) -> dict:
    gender_map = {"M": "male", "F": "female", "male": "male", "female": "female", "UN": "unknown", "UNK": "unknown"}

    gc_el = _find_by_local(root, "administrativeGenderCode")
    bv_el = _find_by_local(root, "birthTime")
    bv = _get_el_attr(bv_el, "value")
    gender_code = _get_el_attr(gc_el, "code", "")

    given_el = _find_by_local(root, "given")
    family_el = _find_by_local(root, "family")
    pat_id = _uuid()

    addr_el = _find_by_local(root, "addr")
    addr_list = []
    if addr_el is not None:
        street_el = _find_by_local(addr_el, "streetAddressLine")
        city_el = _find_by_local(addr_el, "city")
        state_el = _find_by_local(addr_el, "state")
        postal_el = _find_by_local(addr_el, "postalCode")
        entry = {"use": "home"}
        if street_el is not None and street_el.text:
            entry["line"] = [street_el.text.strip()]
        if city_el is not None:
            entry["city"] = (city_el.text or "").strip() or None
        if state_el is not None:
            entry["state"] = (state_el.text or "").strip() or None
        if postal_el is not None:
            entry["postalCode"] = (postal_el.text or "").strip() or None
        entry["country"] = "US"
        if entry.get("line") or entry.get("city"):
            addr_list.append(entry)

    pid_el = _find_by_local(root, "patientRole")
    pid_id_el = None
    if pid_el is not None:
        for child in pid_el:
            if _local(child) == "id":
                pid_id_el = child
                break

    identifiers = []
    if pid_id_el is not None:
        root_val = _get_el_attr(pid_id_el, "root", "2.16.840.1.113883.19")
        ext_val = _get_el_attr(pid_id_el, "extension") or root_val
        identifiers = [{"use": "usual", "system": f"urn:oid:{root_val}", "value": ext_val}]

    return {
        "resourceType": "Patient",
        "id": pat_id,
        "meta": {"profile": ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-patient"]},
        "identifier": identifiers,
        "name": [{"use": "official",
                   "family": _text(family_el) or "",
                   "given": [g for g in [_text(given_el)] if g]}],
        "gender": gender_map.get(gender_code, "unknown"),
        "birthDate": _fhir_date(bv),
        "address": addr_list,
    }


def fhir_conditions(root, pat_id: str) -> list[dict]:
    sec = find_section(root, OID["PROBLEMS"])
    if sec is None:
        return []
    results = []
    for entry in _find_all_by_local(sec, "entry"):
        obs = _find_by_local(entry, "observation")
        if obs is None:
            continue
        code_el = None
        # 1. value[code][codeSystem] anywhere in observation subtree
        for el in obs.iter():
            if _local(el) == "value" and el.get("code") and el.get("codeSystem"):
                code_el = el
                break
        # 2. translation inside value (nullFlavor case: <value nullFlavor="UNK"><translation code=.../>)
        if code_el is None:
            val_el = next((el for el in obs if _local(el) == "value"), None)
            if val_el is not None:
                for child in val_el:
                    if _local(child) == "translation" and child.get("code") and child.get("codeSystem"):
                        code_el = child
                        break
        # 3. code[code][codeSystem] anywhere in observation subtree
        if code_el is None:
            for el in obs.iter():
                if _local(el) == "code" and el.get("code") and el.get("codeSystem"):
                    code_el = el
                    break
        if code_el is None:
            continue
        code = code_el.get("code", "")
        oid = code_el.get("codeSystem", "")
        disp = code_el.get("displayName", "")
        if not code:
            continue

        eff_el = _find_by_local(obs, "effectiveTime")
        low_el = _find_by_local(eff_el, "low") if eff_el is not None else None
        high_el = _find_by_local(eff_el, "high") if eff_el is not None else None
        sc_el = _find_by_local(obs, "statusCode")
        sc = _get_el_attr(sc_el, "code", "")

        results.append({
            "resourceType": "Condition",
            "id": _uuid(),
            "meta": {"profile": ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-condition"]},
            "clinicalStatus": {"coding": [{"system": "http://terminology.hl7.org/CodeSystem/condition-clinical",
                                           "code": "resolved" if sc == "completed" else "active"}]},
            "verificationStatus": {"coding": [{"system": "http://terminology.hl7.org/CodeSystem/condition-ver-status", "code": "confirmed"}]},
            "code": _fcc(code, oid, disp),
            "subject": {"reference": f"Patient/{pat_id}"},
            "onsetDateTime": _fhir_date(_get_el_attr(low_el, "value")),
            "abatementDateTime": _fhir_date(_get_el_attr(high_el, "value")),
        })
    return results


def fhir_medications(root, pat_id: str) -> list[dict]:
    sec = find_section(root, OID["MEDICATIONS"])
    if sec is None:
        return []
    results = []
    for entry in _find_all_by_local(sec, "entry"):
        sa = _find_by_local(entry, "substanceAdministration")
        if sa is None:
            continue
        mat = _find_by_local(sa, "manufacturedMaterial")
        code_el = _find_by_local(mat, "code") if mat is not None else None
        if code_el is None:
            continue
        code = code_el.get("code", "")
        oid = code_el.get("codeSystem", "")
        disp = code_el.get("displayName", "")
        if not code:
            continue

        sc_el = _find_by_local(sa, "statusCode")
        sc = _get_el_attr(sc_el, "code", "")
        eff_el = _find_by_local(sa, "effectiveTime")
        eff_val = _get_el_attr(eff_el, "value") if eff_el is not None else None
        if not eff_val and eff_el is not None:
            low_el = _find_by_local(eff_el, "low")
            eff_val = _get_el_attr(low_el, "value")

        dose_el = _find_by_local(sa, "doseQuantity")
        dose_instr = None
        if dose_el is not None:
            dose_val = dose_el.get("value")
            dose_unit = dose_el.get("unit")
            if dose_val:
                try:
                    dose_instr = [{"doseAndRate": [{"doseQuantity": {
                        "value": float(dose_val), "unit": dose_unit or "",
                        "system": "http://unitsofmeasure.org"
                    }}]}]
                except Exception:
                    pass

        status = "active" if sc == "active" else ("completed" if sc == "completed" else "unknown")
        results.append({
            "resourceType": "MedicationRequest",
            "id": _uuid(),
            "meta": {"profile": ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-medicationrequest"]},
            "status": status,
            "intent": "order",
            "medicationCodeableConcept": _fcc(code, oid, disp),
            "subject": {"reference": f"Patient/{pat_id}"},
            "authoredOn": _fhir_date(eff_val),
            "dosageInstruction": dose_instr,
        })
    return results


def fhir_allergies(root, pat_id: str) -> list[dict]:
    sec = find_section(root, OID["ALLERGIES"])
    if sec is None:
        return []
    results = []
    crit_map = {"255604002": "low", "6736007": "moderate", "24484000": "high", "442452003": "unable-to-assess"}
    for entry in _find_all_by_local(sec, "entry"):
        act = _find_by_local(entry, "act")
        if act is None:
            continue
        pe = _find_by_local(act, "playingEntity")
        code_el = _find_by_local(pe, "code") if pe is not None else None
        if code_el is None:
            continue
        code = code_el.get("code", "")
        oid = code_el.get("codeSystem", "")
        disp = code_el.get("displayName", "")
        if not code:
            continue
        sev_el = _find_by_local(act, "value")
        crit = crit_map.get(_get_el_attr(sev_el, "code", ""), "unable-to-assess")
        results.append({
            "resourceType": "AllergyIntolerance",
            "id": _uuid(),
            "meta": {"profile": ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-allergyintolerance"]},
            "clinicalStatus": {"coding": [{"system": "http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical", "code": "active"}]},
            "verificationStatus": {"coding": [{"system": "http://terminology.hl7.org/CodeSystem/allergyintolerance-verification", "code": "confirmed"}]},
            "type": "allergy",
            "criticality": crit,
            "code": _fcc(code, oid, disp),
            "patient": {"reference": f"Patient/{pat_id}"},
        })
    return results


def fhir_observations(root, pat_id: str) -> list[dict]:
    out = []

    def _extract_obs(sec, category_code: str, category_disp: str, profile: str):
        if sec is None:
            return
        for obs in [el for el in sec.iter() if _local(el) == "observation"]:
            code_el = None
            for child in obs:
                if _local(child) == "code" and child.get("code") and child.get("codeSystem"):
                    code_el = child
                    break
            if code_el is None:
                continue
            code = code_el.get("code", "")
            oid = code_el.get("codeSystem", "")
            disp = code_el.get("displayName", "")
            if not code:
                continue
            val_el = _find_by_local(obs, "value")
            eff_el = _find_by_local(obs, "effectiveTime")
            eff_val = _get_el_attr(eff_el, "value") if eff_el is not None else None
            if not eff_val and eff_el is not None:
                low_el = _find_by_local(eff_el, "low")
                eff_val = _get_el_attr(low_el, "value")

            o = {
                "resourceType": "Observation",
                "id": _uuid(),
                "meta": {"profile": [profile]},
                "status": "final",
                "category": [{"coding": [{"system": "http://terminology.hl7.org/CodeSystem/observation-category",
                                          "code": category_code, "display": category_disp}]}],
                "code": _fcc(code, oid, disp),
                "subject": {"reference": f"Patient/{pat_id}"},
                "effectiveDateTime": _fhir_date(eff_val),
            }
            if val_el is not None:
                v = val_el.get("value")
                u = val_el.get("unit")
                if v:
                    try:
                        o["valueQuantity"] = {"value": float(v), "unit": u or "", "system": "http://unitsofmeasure.org", "code": u or ""}
                    except (ValueError, TypeError):
                        dn = val_el.get("displayName")
                        if dn:
                            o["valueString"] = dn
                        elif val_el.text and val_el.text.strip():
                            o["valueString"] = val_el.text.strip()
            out.append(o)

    _extract_obs(find_section(root, OID["RESULTS"]), "laboratory", "Laboratory",
                 "http://hl7.org/fhir/us/core/StructureDefinition/us-core-observation-lab")
    _extract_obs(find_section(root, OID["VITALS"]), "vital-signs", "Vital Signs",
                 "http://hl7.org/fhir/us/core/StructureDefinition/us-core-vitalsigns")
    return out


def fhir_encounters(root, pat_id: str) -> list[dict]:
    sec = find_section(root, OID["ENCOUNTERS"])
    if sec is None:
        return []
    results = []
    for entry in _find_all_by_local(sec, "entry"):
        enc = _find_by_local(entry, "encounter")
        if enc is None:
            continue
        eff_el = _find_by_local(enc, "effectiveTime")
        start = _get_el_attr(eff_el, "value") if eff_el is not None else None
        if not start and eff_el is not None:
            low_el = _find_by_local(eff_el, "low")
            start = _get_el_attr(low_el, "value")
        end_el = _find_by_local(eff_el, "high") if eff_el is not None else None
        end = _get_el_attr(end_el, "value")
        # Match V15: querySelector('code[code][codeSystem]') finds first coded element
        # anywhere in encounter subtree (inc. entryRelationship > observation > code)
        type_code_el = next(
            (el for el in enc.iter()
             if _local(el) == "code" and el.get("code") and el.get("codeSystem")),
            None
        )
        type_field = None
        if type_code_el is not None:
            tc, toid, tdisp = type_code_el.get("code", ""), type_code_el.get("codeSystem", ""), type_code_el.get("displayName", "")
            if tc:
                type_field = [_fcc(tc, toid, tdisp)]
        # Match V15: diagnosis from entryRelationship[typeCode="RSON"] > observation > code
        diags = []
        for er in enc.iter():
            if _local(er) == "entryRelationship" and er.get("typeCode") == "RSON":
                obs_el = _find_by_local(er, "observation")
                if obs_el is not None:
                    code_el = next((c for c in obs_el if _local(c) == "code" and c.get("code")), None)
                    if code_el is not None:
                        disp = code_el.get("displayName") or code_el.get("code", "")
                        diags.append({
                            "condition": {"display": disp},
                            "use": {"coding": [{"system": "http://terminology.hl7.org/CodeSystem/diagnosis-role", "code": "AD"}]},
                        })
        results.append({
            "resourceType": "Encounter",
            "id": _uuid(),
            "meta": {"profile": ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-encounter"]},
            "status": "finished",
            "class": {"system": "http://terminology.hl7.org/CodeSystem/v3-ActCode", "code": "AMB", "display": "ambulatory"},
            "type": type_field,
            "subject": {"reference": f"Patient/{pat_id}"},
            "period": {"start": _fhir_date(start), "end": _fhir_date(end)},
            "diagnosis": diags if diags else None,
        })
    return results


def fhir_procedures(root, pat_id: str) -> list[dict]:
    sec = find_section(root, OID["PROCEDURES"])
    if sec is None:
        return []
    results = []
    for entry in _find_all_by_local(sec, "entry"):
        proc = _find_by_local(entry, "procedure")
        if proc is None:
            continue
        code_el = None
        for child in proc:
            if _local(child) == "code" and child.get("code") and child.get("codeSystem"):
                code_el = child
                break
        if code_el is None:
            continue
        code = code_el.get("code", "")
        oid = code_el.get("codeSystem", "")
        disp = code_el.get("displayName", "")
        if not code:
            continue
        eff_el = _find_by_local(proc, "effectiveTime")
        eff_val = _get_el_attr(eff_el, "value") if eff_el is not None else None
        if not eff_val and eff_el is not None:
            low_el = _find_by_local(eff_el, "low")
            eff_val = _get_el_attr(low_el, "value")
        sc_el = _find_by_local(proc, "statusCode")
        sc = _get_el_attr(sc_el, "code", "")
        status = "completed" if sc == "completed" else ("in-progress" if sc == "active" else "unknown")
        results.append({
            "resourceType": "Procedure",
            "id": _uuid(),
            "meta": {"profile": ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-procedure"]},
            "status": status,
            "code": _fcc(code, oid, disp),
            "subject": {"reference": f"Patient/{pat_id}"},
            "performedDateTime": _fhir_date(eff_val),
        })
    return results


def fhir_immunizations(root, pat_id: str) -> list[dict]:
    sec = find_section(root, OID["IMMUNIZE"])
    if sec is None:
        return []
    results = []
    for entry in _find_all_by_local(sec, "entry"):
        sa = _find_by_local(entry, "substanceAdministration")
        if sa is None:
            continue
        mat = _find_by_local(sa, "manufacturedMaterial")
        code_el = _find_by_local(mat, "code") if mat is not None else None
        if code_el is None:
            continue
        code = code_el.get("code", "")
        oid = code_el.get("codeSystem", "")
        disp = code_el.get("displayName", "")
        if not code:
            continue
        eff_el = _find_by_local(sa, "effectiveTime")
        eff_val = _get_el_attr(eff_el, "value")
        sc_el = _find_by_local(sa, "statusCode")
        sc = _get_el_attr(sc_el, "code", "")
        results.append({
            "resourceType": "Immunization",
            "id": _uuid(),
            "status": "completed" if sc == "completed" else "not-done",
            "vaccineCode": _fcc(code, oid, disp),
            "patient": {"reference": f"Patient/{pat_id}"},
            "occurrenceDateTime": _fhir_date(eff_val) or "unknown",
            "primarySource": False,
        })
    return results


def build_fhir_bundle(name: str, xml_bytes: bytes) -> dict | None:
    from .parser import parse_xml
    root, err = parse_xml(xml_bytes)
    if root is None or err:
        return None

    patient = fhir_patient(root)
    pat_id = patient["id"]
    conditions    = fhir_conditions(root, pat_id)
    medications   = fhir_medications(root, pat_id)
    allergies     = fhir_allergies(root, pat_id)
    observations  = fhir_observations(root, pat_id)
    encounters    = fhir_encounters(root, pat_id)
    procedures    = fhir_procedures(root, pat_id)
    immunizations = fhir_immunizations(root, pat_id)

    all_resources = [_clean(r) for r in [patient, *conditions, *medications, *allergies,
                     *observations, *encounters, *procedures, *immunizations]]

    counts = {
        "Patient": 1,
        "Condition": len(conditions),
        "MedicationRequest": len(medications),
        "AllergyIntolerance": len(allergies),
        "Observation": len(observations),
        "Encounter": len(encounters),
        "Procedure": len(procedures),
        "Immunization": len(immunizations),
        "total": len(all_resources),
    }

    return {
        "resourceType": "Bundle",
        "id": _uuid(),
        "meta": {
            "lastUpdated": datetime.utcnow().isoformat() + "Z",
            "tag": [{"system": "http://example.org/ccda-ai", "code": "ccda-converted", "display": "Converted from CCDA"}],
        },
        "type": "collection",
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "entry": [{"fullUrl": f"urn:uuid:{r['id']}", "resource": r} for r in all_resources],
        "_meta": {"sourceFile": name, "counts": counts},
    }
