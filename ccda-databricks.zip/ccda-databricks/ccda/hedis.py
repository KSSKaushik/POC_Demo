from .constants import HEDIS_MEASURES, HEDIS_VS_STATIC, SYS_TO_OID, CS


def _all_codes_for_vs(vs_name: str) -> list[dict]:
    vs = HEDIS_VS_STATIC.get(vs_name)
    if not vs:
        return []
    out = []
    for sys_label, codes in vs.get("codes", {}).items():
        sys_oid = SYS_TO_OID.get(sys_label, sys_label)
        for code in codes:
            out.append({"code": code, "sys": sys_oid, "sys_label": sys_label})
    return out


def code_set_matches(vs_name: str, doc_codes: list[dict]) -> dict:
    vs_codes = _all_codes_for_vs(vs_name)
    if not vs_codes:
        return {"hit": False, "matched": []}
    matched = []
    doc_index = {(c["code"], c["sys"]): c.get("disp", "") for c in doc_codes}
    for vc in vs_codes:
        key = (vc["code"], vc["sys"])
        if key in doc_index:
            matched.append({"code": vc["code"], "sys_label": vc["sys_label"], "disp": doc_index[key]})
    return {"hit": len(matched) > 0, "matched": matched}


def _check_denom(root, codes: list[dict], measure: dict) -> bool:
    logic = measure.get("denom_logic", {})
    # Match V15: anyAdult=True, anyFemale=True, or anyAdult not present → include all
    if logic.get("any_adult") or logic.get("any_female") or ("any_adult" not in logic):
        return True
    for vs_name in measure.get("denom_vs", []):
        if code_set_matches(vs_name, codes)["hit"]:
            return True
    return False


def _check_denom_evidence(codes: list[dict], measure: dict) -> dict:
    logic = measure.get("denom_logic", {})
    if logic.get("any_adult") or not logic:
        return {"hit": True, "matched": [{"code": "(population)", "sys_label": "Logic", "disp": "All adults"}]}
    matched = []
    for vs_name in measure.get("denom_vs", []):
        r = code_set_matches(vs_name, codes)
        if r["hit"]:
            matched.extend([{**c, "vs_name": vs_name} for c in r["matched"]])
    return {"hit": len(matched) > 0, "matched": matched}


def _check_numer(codes: list[dict], measure: dict) -> dict:
    matched = []
    for vs_name in measure.get("numer_vs", []):
        r = code_set_matches(vs_name, codes)
        if r["hit"]:
            matched.extend([{**c, "vs_name": vs_name} for c in r["matched"]])
    return {"hit": len(matched) > 0, "matched": matched}


def _check_exclusion(codes: list[dict], measure: dict) -> bool:
    for vs_name in measure.get("exclusion_vs", []):
        if code_set_matches(vs_name, codes)["hit"]:
            return True
    return False


def analyze_hedis(root, codes: list[dict]) -> list[dict]:
    results = []
    for m in HEDIS_MEASURES:
        denom_hit = _check_denom(root, codes, m)
        exclusion_hit = _check_exclusion(codes, m)
        if denom_hit and not exclusion_hit:
            numer_result = _check_numer(codes, m)
            numer_hit = numer_result["hit"]
            numer_matched = numer_result["matched"]
        else:
            numer_hit = False
            numer_matched = []
        denom_ev = _check_denom_evidence(codes, m)

        if denom_hit or numer_hit:
            results.append({
                "id": m["id"],
                "name": m["name"],
                "cat": m["cat"],
                "description": m.get("description", ""),
                "denom_hit": denom_hit,
                "numer_hit": numer_hit,
                "exclusion_hit": exclusion_hit,
                "numer_matched": numer_matched,
                "denom_matched": denom_ev["matched"],
                "numer_vs": m.get("numer_vs", []),
                "denom_vs": m.get("denom_vs", []),
                "exclusion_vs": m.get("exclusion_vs", []),
            })
    return results
