import io
import json
import zipfile
from fastapi import APIRouter, File, UploadFile, HTTPException
from fastapi.responses import StreamingResponse

from ccda.scorer import analyze_file
from ccda.fhir import build_fhir_bundle
from ccda.sql_loader import create_tables, load_bundle, truncate_all, get_table_counts, get_ddl
from ccda.constants import SQL_TABLES, HEDIS_VS_STATIC, LOINC_NAMES
from ccda.samples import SAMPLE_PATIENTS, make_ccda
from database import get_connection

router = APIRouter(prefix="/api/ccda", tags=["ccda"])


@router.post("/analyze")
async def analyze_ccda(files: list[UploadFile] = File(...)):
    results = []
    for f in files:
        content = await f.read()
        result = analyze_file(f.filename or "unknown.xml", content)
        # Remove raw XML from response to keep payload small
        result.pop("xml", None)
        results.append(result)
    return {"results": results, "count": len(results)}


@router.post("/fhir/convert")
async def convert_to_fhir(files: list[UploadFile] = File(...)):
    bundles = []
    for f in files:
        content = await f.read()
        bundle = build_fhir_bundle(f.filename or "unknown.xml", content)
        if bundle:
            # Strip private _meta before returning (keep counts visible)
            meta = bundle.pop("_meta", {})
            bundle["_counts"] = meta.get("counts", {})
            bundle["_source_file"] = meta.get("sourceFile", "")
            bundles.append(bundle)
    return {"bundles": bundles, "count": len(bundles)}


@router.post("/fhir/export-zip")
async def export_fhir_zip(files: list[UploadFile] = File(...)):
    buf = io.BytesIO()
    manifest = {"generated": "", "files": [], "total_resources": 0, "bundles": []}
    from datetime import datetime
    manifest["generated"] = datetime.utcnow().isoformat() + "Z"

    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in files:
            content = await f.read()
            bundle = build_fhir_bundle(f.filename or "unknown.xml", content)
            if not bundle:
                continue
            meta = bundle.pop("_meta", {})
            counts = meta.get("counts", {})
            fname = (f.filename or "unknown").replace(".xml", "") + "_fhir.json"
            zf.writestr(fname, json.dumps(bundle, indent=2, default=str))
            manifest["files"].append(fname)
            manifest["total_resources"] += counts.get("total", 0)
            manifest["bundles"].append({"file": f.filename, **counts})

        zf.writestr("manifest.json", json.dumps(manifest, indent=2))

    buf.seek(0)
    return StreamingResponse(
        buf,
        media_type="application/zip",
        headers={"Content-Disposition": "attachment; filename=ccda-fhir-export.zip"},
    )


@router.get("/sql/ddl")
async def get_sql_ddl():
    return {"ddl": get_ddl(), "tables": SQL_TABLES}


@router.post("/sql/create-tables")
async def sql_create_tables():
    try:
        conn = get_connection()
        result = create_tables(conn)
        conn.close()
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/sql/load")
async def sql_load_bundles(files: list[UploadFile] = File(...)):
    try:
        conn = get_connection()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB connection failed: {e}")

    total_inserted = 0
    errors = []
    for f in files:
        content = await f.read()
        bundle = build_fhir_bundle(f.filename or "unknown.xml", content)
        if not bundle:
            errors.append(f"{f.filename}: FHIR conversion failed")
            continue
        # Restore _meta for loader
        meta_counts = bundle.pop("_counts", {})
        meta_source = bundle.pop("_source_file", f.filename or "unknown")
        bundle["_meta"] = {"sourceFile": meta_source, "counts": meta_counts}
        res = load_bundle(conn, bundle)
        if res["success"]:
            total_inserted += res["rows_inserted"]
        else:
            errors.append(f"{f.filename}: {res.get('message', 'unknown error')}")

    conn.close()
    return {
        "success": len(errors) == 0,
        "total_rows_inserted": total_inserted,
        "files_processed": len(files),
        "errors": errors,
    }


@router.get("/sql/status")
async def sql_status():
    try:
        conn = get_connection()
        counts = get_table_counts(conn)
        conn.close()
        return {"connected": True, "table_counts": counts, "tables": SQL_TABLES}
    except Exception as e:
        return {"connected": False, "error": str(e), "table_counts": {}, "tables": SQL_TABLES}


@router.post("/sql/truncate")
async def sql_truncate():
    try:
        conn = get_connection()
        result = truncate_all(conn)
        conn.close()
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/meta/value-sets")
async def get_value_sets():
    vs_list = []
    for name, vs in HEDIS_VS_STATIC.items():
        codes_map = vs.get("codes", {})
        total_codes = sum(len(c) for c in codes_map.values())
        vs_list.append({
            "name": name,
            "oid": vs.get("oid"),
            "measure": vs.get("measure"),
            "role": vs.get("role"),
            "total_codes": total_codes,
            "systems": list(codes_map.keys()),
            "systems_counts": {sys: len(codes) for sys, codes in codes_map.items()},
        })
    return {"value_sets": vs_list, "count": len(vs_list)}


@router.get("/meta/loinc-names")
async def get_loinc_names():
    return {"loinc_names": LOINC_NAMES}


@router.get("/samples")
async def get_samples():
    results = []
    fhir_bundles = []
    for s in SAMPLE_PATIENTS:
        xml_str = make_ccda(**s["params"])
        xml_bytes = xml_str.encode("utf-8")
        result = analyze_file(s["name"], xml_bytes)
        result.pop("xml", None)
        results.append(result)
        bundle = build_fhir_bundle(s["name"], xml_bytes)
        if bundle:
            meta = bundle.pop("_meta", {})
            bundle["_counts"] = meta.get("counts", {})
            bundle["_source_file"] = meta.get("sourceFile", s["name"])
            fhir_bundles.append(bundle)
    return {"results": results, "fhir_bundles": fhir_bundles, "count": len(results)}
