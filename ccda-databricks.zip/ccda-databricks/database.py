"""
Stub database module for Databricks deployment.
SQL Server Loader tab will show a connection error (expected — no SQL Server on Databricks).
All other CCDA features (analyze, FHIR convert, HEDIS, LOINC, Narrative) work normally.
"""
def get_connection():
    raise RuntimeError(
        "SQL Server is not available in the Databricks deployment. "
        "The SQL Server Loader tab requires a SQL Server connection."
    )
